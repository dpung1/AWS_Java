package ch08_생성자;

public class ConstructorMain {
	public static void main(String[] args) {
		Constructor01 constructor01 = new Constructor01();
		System.out.println(constructor01);
		
		Constructor01 constructor02 = new Constructor01("정대풍", 27);
		System.out.println(constructor02);
		
		
	}
}
