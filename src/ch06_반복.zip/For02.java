package ch06_반복;


public class For02 {
	public static void main(String[] args) {
		
		for(int i = 0; i < 10; i++) {
			System.out.println(i + 1);
			
		}	
		
		String str = "코리아아이티";
		System.out.println(str.substring(0, 3));		
	}
}
